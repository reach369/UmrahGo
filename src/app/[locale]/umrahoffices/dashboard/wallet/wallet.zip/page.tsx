'use client';

/**
 * Enhanced Wallet Page - Umrah Offices
 * Professional wallet management with comprehensive features and error handling
 */

import React, { useState, useEffect, useCallback } from 'react';
import { useTranslations } from 'next-intl';
import { toast } from 'sonner';
import { 
  Wallet, 
  TrendingUp, 
  TrendingDown, 
  CreditCard, 
  Download, 
  Upload,
  RefreshCw,
  AlertCircle,
  Settings,
  Eye,
  EyeOff,
  ArrowUpRight,
  ArrowDownRight,
  Loader2,
  DollarSign,
  Banknote,
  BarChart3,
  PieChart
} from 'lucide-react';

// UI Components
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Alert,
  AlertDescription,
  AlertTitle,
} from '@/components/ui/alert';

// Wallet Components
import { WalletDashboard } from '@/components/office/enhanced-wallet/WalletDashboard';
import { WalletStatistics } from '@/components/office/enhanced-wallet/WalletStatistics';
import { WithdrawalRequests } from '@/components/office/enhanced-wallet/WithdrawalRequests';
import { TransactionsTable } from '@/components/office/enhanced-wallet/TransactionsTable';
import { WalletReports } from '@/components/office/enhanced-wallet/WalletReports';
import { SystemStatus } from '@/components/office/enhanced-wallet/SystemStatus';

// Services
import enhancedWalletService, { 
  DashboardData, 
  WalletBalance, 
  WalletTransaction, 
  SystemStatus as SystemStatusType,
  ApiResponse 
} from '@/services/api/enhanced-wallet';

// Utils
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import { ar } from 'date-fns/locale';

// Types
interface WalletPageState {
  dashboardData: DashboardData | null;
  systemStatus: SystemStatusType | null;
  isLoading: boolean;
  isRefreshing: boolean;
  error: string | null;
  showBalance: boolean;
  lastUpdated: Date | null;
}

interface QuickAction {
  id: string;
  title: string;
  description: string;
  icon: React.ElementType;
  color: string;
  bgColor: string;
  action: () => void;
  disabled?: boolean;
}

export default function WalletPage() {
  const t = useTranslations('wallet');
  
  // State management
  const [state, setState] = useState<WalletPageState>({
    dashboardData: null,
    systemStatus: null,
    isLoading: true,
    isRefreshing: false,
    error: null,
    showBalance: true,
    lastUpdated: null
  });

  const [activeTab, setActiveTab] = useState('overview');

  // Format currency
  const formatCurrency = useCallback((amount: number) => {
    return enhancedWalletService.formatCurrency(amount);
  }, []);

  // Load wallet data with comprehensive error handling
  const loadWalletData = useCallback(async (showLoading = true) => {
    try {
      if (showLoading) {
        setState(prev => ({ ...prev, isLoading: true, error: null }));
      } else {
        setState(prev => ({ ...prev, isRefreshing: true }));
      }

      // Parallel data fetching for better performance
      const [dashboardResponse, systemStatusResponse] = await Promise.allSettled([
        enhancedWalletService.getDashboard(),
        enhancedWalletService.getSystemStatus()
      ]);

      // Process dashboard data
      let dashboardData: DashboardData | null = null;
      let dashboardError: string | null = null;
      
      if (dashboardResponse.status === 'fulfilled' && dashboardResponse.value.status === 'success') {
        dashboardData = dashboardResponse.value.data!;
      } else if (dashboardResponse.status === 'rejected') {
        console.error('Dashboard fetch failed:', dashboardResponse.reason);
        dashboardError = 'خطأ في تحميل بيانات المحفظة';
      }

      // Process system status
      let systemStatus: SystemStatusType | null = null;
      let systemError: string | null = null;
      
      if (systemStatusResponse.status === 'fulfilled' && systemStatusResponse.value.status === 'success') {
        systemStatus = systemStatusResponse.value.data!;
      } else if (systemStatusResponse.status === 'rejected') {
        console.error('System status fetch failed:', systemStatusResponse.reason);
        systemError = 'خطأ في تحميل حالة النظام';
      }

      // Determine overall error state
      const hasErrors = !dashboardData;
      const errorMessage = dashboardError || (hasErrors ? 'فشل في تحميل بيانات المحفظة' : null);

      setState(prev => ({
        ...prev,
        dashboardData,
        systemStatus,
        isLoading: false,
        isRefreshing: false,
        error: errorMessage,
        lastUpdated: new Date()
      }));

      if (errorMessage) {
        toast.error(errorMessage);
      } else if (dashboardData) {
        if (!showLoading) {
          toast.success('تم تحديث بيانات المحفظة بنجاح');
        }
      }

    } catch (error) {
      console.error('Wallet data loading error:', error);
      const errorMessage = 'خطأ غير متوقع في تحميل بيانات المحفظة';
      
      setState(prev => ({
        ...prev,
        isLoading: false,
        isRefreshing: false,
        error: errorMessage
      }));
      
      toast.error(errorMessage);
    }
  }, []);

  // Auto-refresh data
  useEffect(() => {
    loadWalletData();
    
    // Set up auto-refresh every 5 minutes
    const interval = setInterval(() => {
      loadWalletData(false);
    }, 5 * 60 * 1000);

    return () => clearInterval(interval);
  }, [loadWalletData]);

  // Quick actions configuration
  const quickActions: QuickAction[] = [
    {
      id: 'withdraw',
      title: 'طلب سحب',
      description: 'إنشاء طلب سحب جديد',
      icon: Download,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50',
      action: () => setActiveTab('withdrawals'),
      disabled: !state.dashboardData?.wallets.cash.is_active && !state.dashboardData?.wallets.online.is_active
    },
    {
      id: 'transactions',
      title: 'المعاملات',
      description: 'عرض تاريخ المعاملات',
      icon: CreditCard,
      color: 'text-green-600',
      bgColor: 'bg-green-50',
      action: () => setActiveTab('transactions')
    },
    {
      id: 'reports',
      title: 'التقارير',
      description: 'تقارير مالية مفصلة',
      icon: BarChart3,
      color: 'text-purple-600',
      bgColor: 'bg-purple-50',
      action: () => setActiveTab('reports')
    },
    {
      id: 'statistics',
      title: 'الإحصائيات',
      description: 'إحصائيات الأداء',
      icon: PieChart,
      color: 'text-orange-600',
      bgColor: 'bg-orange-50',
      action: () => setActiveTab('statistics')
    }
  ];

  // Toggle balance visibility
  const toggleBalanceVisibility = useCallback(() => {
    setState(prev => ({ ...prev, showBalance: !prev.showBalance }));
  }, []);

  // Manual refresh
  const handleRefresh = useCallback(() => {
    loadWalletData(false);
  }, [loadWalletData]);

  // Loading state
  if (state.isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 p-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-center min-h-[500px]">
            <div className="text-center">
              <Loader2 className="h-12 w-12 animate-spin text-blue-600 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">جاري تحميل المحفظة</h3>
              <p className="text-gray-600">يرجى الانتظار...</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Error state
  if (state.error && !state.dashboardData) {
    return (
      <div className="min-h-screen bg-gray-50 p-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-center min-h-[500px]">
            <div className="text-center">
              <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">خطأ في تحميل المحفظة</h3>
              <p className="text-gray-600 mb-4">{state.error}</p>
              <Button onClick={() => loadWalletData()} disabled={state.isRefreshing}>
                {state.isRefreshing ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin mr-2" />
                    جاري إعادة المحاولة...
                  </>
                ) : (
                  <>
                    <RefreshCw className="h-4 w-4 mr-2" />
                    إعادة المحاولة
                  </>
                )}
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6" dir="rtl">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-4 space-x-reverse">
              <div className="h-12 w-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <Wallet className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-gray-900">محفظة المكتب</h1>
                <p className="text-gray-600">إدارة شاملة للمحفظة المالية</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-3 space-x-reverse">
              <Button
                variant="outline"
                size="sm"
                onClick={toggleBalanceVisibility}
                className="flex items-center space-x-2 space-x-reverse"
              >
                {state.showBalance ? (
                  <EyeOff className="h-4 w-4" />
                ) : (
                  <Eye className="h-4 w-4" />
                )}
                <span>{state.showBalance ? 'إخفاء الأرصدة' : 'إظهار الأرصدة'}</span>
              </Button>
              
              <Button
                variant="outline"
                size="sm"
                onClick={handleRefresh}
                disabled={state.isRefreshing}
                className="flex items-center space-x-2 space-x-reverse"
              >
                <RefreshCw className={cn("h-4 w-4", state.isRefreshing && "animate-spin")} />
                <span>تحديث</span>
              </Button>
            </div>
          </div>

          {/* Last updated indicator */}
          {state.lastUpdated && (
            <div className="text-sm text-gray-500">
              آخر تحديث: {format(state.lastUpdated, 'yyyy/MM/dd HH:mm', { locale: ar })}
            </div>
          )}
        </div>

        {/* System Status Alert */}
        {state.systemStatus && state.systemStatus.overall_health_percentage < 80 && (
          <Alert className="mb-6 border-yellow-200 bg-yellow-50">
            <AlertCircle className="h-4 w-4 text-yellow-600" />
            <AlertTitle className="text-yellow-800">تحذير النظام</AlertTitle>
            <AlertDescription className="text-yellow-700">
              صحة النظام: {state.systemStatus.overall_health_percentage.toFixed(1)}%
              - يرجى مراجعة حالة النظام
            </AlertDescription>
          </Alert>
        )}

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {quickActions.map((action) => (
            <Card 
              key={action.id}
              className={cn(
                "cursor-pointer hover:shadow-md transition-shadow",
                action.disabled && "opacity-50 cursor-not-allowed"
              )}
              onClick={action.disabled ? undefined : action.action}
            >
              <CardContent className="p-6">
                <div className="flex items-center space-x-4 space-x-reverse">
                  <div className={cn("h-12 w-12 rounded-lg flex items-center justify-center", action.bgColor)}>
                    <action.icon className={cn("h-6 w-6", action.color)} />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-900">{action.title}</h3>
                    <p className="text-sm text-gray-600">{action.description}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Main Content Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="overview">نظرة عامة</TabsTrigger>
            <TabsTrigger value="transactions">المعاملات</TabsTrigger>
            <TabsTrigger value="withdrawals">طلبات السحب</TabsTrigger>
            <TabsTrigger value="statistics">الإحصائيات</TabsTrigger>
            <TabsTrigger value="reports">التقارير</TabsTrigger>
            <TabsTrigger value="system">حالة النظام</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <WalletDashboard 
              dashboardData={state.dashboardData}
              showBalance={state.showBalance}
              isRefreshing={state.isRefreshing}
              onRefresh={handleRefresh}
            />
          </TabsContent>

          <TabsContent value="transactions" className="space-y-6">
            <TransactionsTable />
          </TabsContent>

          <TabsContent value="withdrawals" className="space-y-6">
            <WithdrawalRequests />
          </TabsContent>

          <TabsContent value="statistics" className="space-y-6">
            <WalletStatistics />
          </TabsContent>

          <TabsContent value="reports" className="space-y-6">
            <WalletReports />
          </TabsContent>

          <TabsContent value="system" className="space-y-6">
            <SystemStatus systemStatus={state.systemStatus} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
} 