'use client';

import React from 'react';
import { useTranslations } from 'next-intl';
import SystemStatus from '@/components/office/enhanced-wallet/SystemStatus';

interface SystemStatusPageProps {
  params: { locale: string };
}

export default function SystemStatusPage({ params }: SystemStatusPageProps) {
  const t = useTranslations();
  const locale = params.locale || 'ar';

  return (
    <div className="space-y-6" dir={locale === 'ar' ? 'rtl' : 'ltr'}>
      <SystemStatus showActions={true} />
    </div>
  );
} 